%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-05-30T15:03:51+01:00*%
%TF.ProjectId,omron-g2r-s-terminal,6f6d726f-6e2d-4673-9272-2d732d746572,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-05-30 15:03:51*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.300000X-1.200000X-1.200000X1.200000X-1.200000X1.200000X1.200000X-1.200000X1.200000X0*%
%ADD11C,3.000000*%
%ADD12RoundRect,0.300000X-2.700000X-0.700000X2.700000X-0.700000X2.700000X0.700000X-2.700000X0.700000X0*%
%ADD13RoundRect,0.300000X0.700000X-2.700000X0.700000X2.700000X-0.700000X2.700000X-0.700000X-2.700000X0*%
%ADD14RoundRect,0.300000X1.200000X1.200000X-1.200000X1.200000X-1.200000X-1.200000X1.200000X-1.200000X0*%
G04 APERTURE END LIST*
D10*
%TO.C,J1*%
X152500000Y-123000000D03*
D11*
X147500000Y-123000000D03*
%TD*%
D12*
%TO.C,K1*%
X150050000Y-94800000D03*
X150050000Y-100000000D03*
X150050000Y-89600000D03*
D13*
X146300000Y-112300000D03*
X153800000Y-112300000D03*
%TD*%
D14*
%TO.C,J2*%
X145000000Y-82500000D03*
D11*
X150000000Y-82500000D03*
X155000000Y-82500000D03*
%TD*%
M02*
